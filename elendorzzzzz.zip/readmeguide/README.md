Group members: <br/>
• Pierre E.S Moningka - 00000128411  <br/>
• Tito Shafy - 00000127746 <br/>
• Muhamad Altha Rasjid - 00000136220 <br/>
• Dylan Wilson - 00000134282 <br/>

---RULES---<br/>
• 1 minute in-game means 1 second in real life.<br/>
• There are 7 statuses that you need to know, namely: HP, Hunger, Stamina, Attack, Speed, Armor, and Gold.<br/>
• HP can be reduced and restored on many occassions during the game, but HP touches 0, you will die and forced to reset your progress.<br/>
• Hunger will decrease overtime, keep your hunger bar high as otherwise it will start depeleting your HP.<br/>
• There are 3 types of movement to move in this game, namely: WASD keys, On-screen D-pad, and Touch the map.<br/>
• Press shift to run, but it will deplete your stamina bar.<br/>
• Press M to open the map to figure out where you are.<br/>
• Press E to interact with locations.<br/>
• Press esc to open the pause menu.<br/>
• The Actions D-pad is used for E(Interact), M(Map), R(Run), P(Pause), and S(Status).












